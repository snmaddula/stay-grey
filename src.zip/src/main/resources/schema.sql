create table delegation (
    id bigint not null,
    delegate_brid varchar(255),
    delegate_name varchar(255),
    delegater_brid varchar(255),
    delegation_type varchar(255),
    delete_flag varchar(255),
    email_summary_flag varchar(255),
    end_ts timestamp,
    last_updated_by varchar(255),
    last_updated_ts timestamp,
    rational varchar(255),
    start_ts timestamp,
    status varchar(255),
    primary key (id)
);

create table delegation_task (
    delegation_id bigint not null,
    product_journey_task_id bigint not null,
    primary key (delegation_id, product_journey_task_id)
); 

create table product_journey (
    id bigint not null,
    product_journey_name varchar(255),
    primary key (id)
);

create table product_journey_task (
    id bigint not null,
    task_name varchar(255),
    product_journey_id bigint not null,
    primary key (id)
);

create sequence hibernate_sequence start with 1 increment by 1;

alter table delegation_task add foreign key (product_journey_task_id) references product_journey_task(id);

alter table delegation_task add foreign key (delegation_id) references delegation(id);

alter table product_journey_task add foreign key (product_journey_id) references product_journey(id);

