
Array.prototype.remove = function (v) {
  if (this.indexOf(v) != -1) {
      this.splice(this.indexOf(v), 1)
      return true
  }
  return false
};

var INDEX = 0
var _INDEX = 0
var context = ''
var PRODUCT_JOURNEY_TASKS = {}
var PRODUCT_JOURNEYS = []
var TASKS_ADDED = []
var DELEGATION = {}
var _DELEGATION = {}
const ADDED_TASK_CARD = 
`
<hr>
<div class="form-row">
  <div class="col-sm-1">&nbsp;</div>
  <div class="col-sm-9">
    <p><span class="badge badge-pill badge-primary index" style="font-size:14px;">_INDEX_</span><span>&nbsp;&nbsp;</span><span class="journey">_TASK_TYPE_ _PRODUCT_JOURNEY_</span></p>
    <span style="font-size:12px;" class="tasks">_TASK_NAMES_</span>
  </div>
  <div class="col-sm-1">
	  <div class="dropdown show">
	      <img class="rounded-circle dropdown-toggle" data-toggle="dropdown" src="img/settings.png" alt="User picture" style="max-width: 60%" aria-haspopup="true" aria-expanded="false">
	      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
	        <a class="dropdown-item edit-task" href="#">Edit</a>
	        <a class="dropdown-item delete-task" href="#">Delete</a>
	      </div>
	    </div>
  </div>
</div>
`;

let ADMIN_ROW =
`
<tr>
<td style="display:none">INDEX</td>
<td>_DELEGATE_</td>
<td>_D_T_T_</td>
<td>_P_J_T_N_</td>
<td>_START_DATE_</td>
<td>_END_DATE_</td>
<td>_LAST_UPDATED_</td>
<td>_STATUS_</td>
<td style="max-width:40px; align:left;">
    <div class="dropdown show">
      <img class="rounded-circle dropdown-toggle" data-toggle="dropdown" src="img/settings.png" alt="User picture" style="max-width: 40%" aria-haspopup="true" aria-expanded="false">
      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <a class="dropdown-item edit-delegation" href="#">Edit</a>
        <a class="dropdown-item duplicate-delegation" href="#">Duplicate</a>
        <a class="dropdown-item delete-delegation" href="#">Delete</a>
      </div>
    </div>
</td>
</tr>
`;

const TASK_CARD = 
`
<div class="custom-control custom-checkbox">
	<input type="checkbox" class="xcheckbox custom-control-input" id="CHECKBOX_ID"> 
	<label class="custom-control-label" for="CHECKBOX_ID">_TASK_NAME_</label>
</div>
`;

const SUCCESS_MESSAGE =
`Your delegation was successfully set. It is your responsibility now to contact <b>_DELEGATE_</b> and make sure he is fine with this duty.`;
	
jQuery(function ($) {
	
	fetchDelegations()
    $(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200)
    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .parent()
        .removeClass("active")
    } else {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200)
      $(this)
        .parent()
        .addClass("active")
    }
  })


  $('#added-tasks').hide()
  
  $('#selectDelegate').editableSelect('destroy')

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })


  $('#selectTaskType').on('change', function() {
      $('#select-journey').show()
  })
  
  $('#_selectTaskType').on('change', function() {
      $('#_select-journey').show()
  })

  $('#select-journey').on('change', function() {
      $('.task-names').show()
  })

  $('#start-delegation').on('click', function() {
	DELEGATION = {}
	context = 'NEW'
    $('#added-tasks').hide()
    $('.task-names').hide()
    $('#select-journey').hide()
    $('#select-task-type').hide()
    $('.select-task-journey').hide()
    $('.add-rational').hide()
    $('.email-check').hide()
    $('.set-dates').hide()
    $('#selectDelegate').val('')
    $('#selectJourney').val('')
    $('#selectTaskType').val('')
    $('#rational').val('')
    $('#addedTasks').html('')
    $('.added-tasks').hide()
    $('#selectDelegate').editableSelect('destroy')
    $('.submit-delegation').hide()

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })

    $('.nav').addClass('nav-view');
    $('.take-inputs').show()
	$('.show-result').hide()
    $('#new-delegation-form').show()
    $('form[name="new"]').show();
    $('form[name="update"]').hide();
  })

  $('.close-form').on('click', function() {
    $('.nav').toggleClass('nav-view');
  })

  $("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled")
  })

  $("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled")
  })

  $('.settings').on('click', function() {

  })

})

$.ajax({
  url: 'api/delegation/tasks',
  success: function(response) {
	  $('#selectJourney').html('<option value=""></option>')
	  PRODUCT_JOURNEY_TASKS = response;
      $.each(PRODUCT_JOURNEY_TASKS, function(k,v) {
    	  PRODUCT_JOURNEYS.push(k)
    	  $('#selectJourney').html($('#selectJourney').html() + '<option value="' + k +'">' + k + '</option>');
    	  $('#_selectJourney').html($('#_selectJourney').html() + '<option value="' + k +'">' + k + '</option>');
	  });
  }
});
	  
$('#selectJourney').on('change', function() {
	  var journey = $('#selectJourney').val();
	  if(journey != '') {
		  var tasksHtml = '';
		  $.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
			  tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
		  });
	  }
	  $('#task-names-list').html(tasksHtml)
	  $('.task-names').show()
});

$('#_selectJourney').on('change', function() {
	  var journey = $('#_selectJourney').val();
	  if(journey != '') {
		  var tasksHtml = '';
		  $.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
			  tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
		  });
	  }
	  $('#_task-names-list').html(tasksHtml)
	  $('.task-names').show()
});

$(document).on('click', '.edit-delegation', function() {
	var _id = $(this).closest('tr').find("td:first").html().trim();
	context = 'EDIT'
	editDelegation(_id)
})

$(document).on('click', '.duplicate-delegation', function() {
	var _id = $(this).closest('tr').find("td:first").html().trim();
	context = 'DUPLICATE'
	editDelegation(_id)
})

$(document).on('click', '.delete-delegation', function() {
	var _id = $(this).closest('tr').find("td:first").html().trim();
	deleteDelegation(_id)
})

$(document).on('click', '.delete-task', function() {
	deleteTask($(this))
})

$(document).on('click', '.edit-task', function() {
	var journey = $(this).closest('.form-row').find(".journey").html().replace('Supervisor ', '').trim();
	var tasks = $(this).closest('.form-row').find(".tasks").html().trim().split(',');
	deleteTask($(this))
	
	//list all the checkboxes and keep the selected one's checked
	var tasksHtml = '';
	$.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
		tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
	});


	switch(context) {
		case 'EDIT': {
			  $('#_select-task-type').show()
			  $('#_select-journey').show()
			  $('#_selectJourney').val(journey)
			  $('#_selectTaskType').val('Supervisor')
			  $('#_task-names-list').html(tasksHtml)
			  $('#_addTask').show()
			break;
		}
	
		case 'NEW': {
			$('#select-task-type').show()
			$('#selectJourney').val(journey)
			$('#selectTaskType').val('Supervisor')

			$('#task-names-list').html(tasksHtml)
			$('#addTask').show()
			break;
		}
	}
	
	$('.xcheckbox').each(function(i, obj){
		var id = $(this).attr('id');
		var _task = $('label[for="'+id+'"]').html().trim();
	    if(tasks.indexOf(_task) > -1) {
	    	$('#'+id).attr('checked', true)
	    }
	});

	$('#_addMoreTasks').hide()
	$('.select-task-journey').show()
	$('.task-names').show()
	$('.add-task').show()
})


function deleteTask(card) {
	var index = $(card).closest('.form-row').find(".index").html().trim();
	var journey = $(card).closest('.form-row').find(".journey").html().replace('Supervisor ', '').trim();
	var tasks = $(card).closest('.form-row').find(".tasks").html().trim().split(',');
	switch(context) {
		case 'EDIT': {
			_INDEX--;
			$.each(tasks, function(i, v){
				_DELEGATION.productJourneyTasks.splice(_DELEGATION.productJourneyTasks.findIndex(_t => _t.productJourneyTaskId == PRODUCT_JOURNEY_TASKS[journey][v]), 1);
			})
			break;
		}
	
		case 'NEW': {
			INDEX--;
			$.each(tasks, function(i, v){
				DELEGATION.productJourneyTasks.splice(DELEGATION.productJourneyTasks.findIndex(_t => _t.productJourneyTaskId == PRODUCT_JOURNEY_TASKS[journey][v]), 1);
			})
			break;
		}
	}
	$(card).closest('.form-row').remove()
	
	$('.index').each(function(i, obj) {
		$(this).html(parseInt($(this).html()) - 1)
	});
}

$(document).on("change", ".xcheckbox", function () {
    var _id = $(this)[0].id
    var _tn = $('label[for="' + _id + '"').text()  
    if(this.checked) {
      TASKS_ADDED.push(_tn)
        $('.add-task').show()
        $('#addTask').show()
        $('#_addTask').show()
        $('#'+ _id).attr('checked', 'checked');
    }else {
    	$('#'+ _id).removeAttr('checked');
      TASKS_ADDED.remove(_tn)
      if($('input[checked="checked"]').length == 0) {
        $('.add-task').hide()
        $('#addTask').hide()
        $('#_addTask').hide()
      }
    }
});


$('#emailCheck').on('change', function() {
	if(this.checked) {
		DELEGATION.emailSummaryFlag = "Y"
	}else {
		DELEGATION.emailSummaryFlag = "N"
	}
});

$('#_emailCheck').on('change', function() {
	if(this.checked) {
		_DELEGATION.emailSummaryFlag = "Y"
	}else {
		_DELEGATION.emailSummaryFlag = "N"
	}
});

$('#addMoreTasks').on('click', function() {
  $('.select-task-journey').show()
  $('#select-task-type').show()
  $('#selectJourney').val('')
  $('#selectTaskType').val('')
})

$('#_addMoreTasks').on('click', function() {
  $('.select-task-journey').show()
  $('#_select-task-type').show()
  $('#_selectJourney').val('')
  $('#_selectTaskType').val('')
})

$('#addTask').on('click', function() {
  var _tt = $('#selectTaskType').val()
  var _pj = $('#selectJourney').val()
  INDEX++
  var card = ADDED_TASK_CARD.replace('_INDEX_', INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
  $('#addedTasks').html( $('#addedTasks').html() + card)
  $('#addedTasks').show()
  $('.added-tasks').show()
  $('.task-names').hide()
  $('.select-task-journey').hide()
  $('#select-task-type').hide()
  $('.add-task').hide()
  
  $.each(TASKS_ADDED, function(i, v) {
	  if(DELEGATION.productJourneyTasks == undefined) {
		  DELEGATION.productJourneyTasks = []
	  }
	  DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[_pj][v] });
  });
  
  TASKS_ADDED = []
  $('.add-rational').show()
  $('.email-check').show()
  $('.set-dates').show()
  $('.submit-delegation').show()
  $('#addMoreTasks').show()
  
})

$('#_addTask').on('click', function() {
  var _tt = $('#_selectTaskType').val()
  var _pj = $('#_selectJourney').val()
  _INDEX++
  var card = ADDED_TASK_CARD.replace('_INDEX_', _INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
  $('#_addedTasks').html( $('#_addedTasks').html() + card)
  $('#_addedTasks').show()
  $('.added-tasks').show()
  $('.task-names').hide()
  $('.select-task-journey').hide()
  $('#_select-task-type').hide()
  $('.add-task').hide()
  
  $.each(TASKS_ADDED, function(i, v) {
	  if(_DELEGATION.productJourneyTasks == undefined) {
		  _DELEGATION.productJourneyTasks = []
	  }
	  _DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[_pj][v] });
  });
  
  TASKS_ADDED = []
  $('.add-rational').show()
  $('.email-check').show()
  $('.set-dates').show()
  $('.submit-delegation').show()
  
  $('#_addMoreTasks').show()
  
})

$('#submitDelegation').click(function() {
	DELEGATION.rational = $('#rational').val().trim();
	DELEGATION.delegateName = $('#selectDelegate').val()
	DELEGATION.delegateBrid = 'G12345';
	DELEGATION.startTs = $('#start_date').val()
	DELEGATION.endTs = $('#end_date').val()
	DELEGATION.delegationType = $('#selectTaskType').val()
	INDEX = 0;
	$.ajax({
		url: 'api/saveDelegation',
		type: 'POST',
		contentType: 'application/json',
		data: JSON.stringify(DELEGATION),
		success: function(response) {
			$('.take-inputs').hide()
			$('.delegation-success').html(SUCCESS_MESSAGE.replace('_DELEGATE_', DELEGATION.delegateName));
			$('.show-result').show()
			fetchDelegations()
		}
	});
})


$('#startDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	sideBySide: true,
	defaultDate : moment(),
}).on("dp.change", function(e) {
	$('#endDate').data("DateTimePicker").minDate(e.date);
});

$('#endDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	sideBySide: true,
	defaultDate : moment()
});


function deleteDelegation(id) {
	$.ajax({
		url: 'api/delegation/' + id,
		type: 'DELETE',
		success: function(response) {
			alert('Deleted delegation : ' + id)
			fetchDelegations()
		},
		error: function(e) {
			
		}
	});
}

$('#_startDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	sideBySide: true,
	defaultDate : moment()
}).on("dp.change", function(e) {
	$('#_endDate').data("DateTimePicker").minDate(e.date);
});

$('#_endDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	sideBySide: true,
	defaultDate : moment()
});

function editDelegation(id) {
	$('.task-names').hide();
	$('#_task-names-list').html('');
	$('#_addedTasks').html();
	$('.show-upd-result').hide()
	
	var url = 'delegation'
	var type = 'POST'
	
	if(context == 'DUPLICATE') {
		$('#updateDelegation').html('Duplicate Delegation')
		url = 'api/saveDelegation'
		type = 'POST'
	}else {
		$('#updateDelegation').html('Update Delegation')
		url = 'api/delegation/' + id
		type = 'PUT'
	}
	
	$.ajax({
		url: 'api/delegation/' + id,
		success: function(response) {
			if(response) {
				_DELEGATION = {}
				_INDEX = 0
				$('#_rational').val(response.rational);
				$('#_selectDelegate').val(response.delegateName);
				$('#_startDate').data("DateTimePicker").date(null)
				$('#_endDate').data("DateTimePicker").date(null)
				$('#_startDate').data("DateTimePicker").date(moment(response.startTs, 'DD MMM YYYY HH:mm'))
				$('#_endDate').data("DateTimePicker").date(moment(response.endTs, 'DD MMM YYYY HH:mm'))
				$('#_selectTaskType').val(response.delegationType)
				$('#_emailCheck').attr('checked', response.emailSummaryFlag == 'Y')

				$('#_addedTasks').html('')
				
				if(_DELEGATION.productJourneyTasks == undefined) {
					_DELEGATION.productJourneyTasks = []
				}
				var tasksHtml = '';
				$.each(response.productJourneyTasks, function(k,v) {
					_INDEX++;
					var card = ADDED_TASK_CARD.replace('_INDEX_', _INDEX).replace('_TASK_TYPE_', response.delegationType).replace('_PRODUCT_JOURNEY_', k).replace('_TASK_NAMES_', v.join())
					  $('#_addedTasks').html( $('#_addedTasks').html() + card)
					  $('#_addedTasks').show()
					  $('.added-tasks').show()
					  $('.task-names').hide()
					  $('.select-task-journey').hide()
					  $('#select-task-type').hide()
					  $('.add-task').hide()
					  
					  $.each(v, function(a, b) {
						  _DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[k][b]});
					  })
				})
				
				$('#added-tasks').show()
			    $('.task-names').show()
			    $('#select-journey').show()
			    $('#select-task-type').hide()
			    $('.select-task-journey').hide()
			    $('.add-rational').show()
			    $('.email-check').show()
			    $('.set-dates').show()
			    $('.added-tasks').show()
			    $('.submit-delegation').hide()

			    $('.nav').addClass('nav-view');
			    $('.take-inputs').show()
				$('.show-result').hide()
			    $('#new-delegation-form').show()
			    $('form[name="new"]').hide();
			    $('form[name="update"]').show();
			    
			    $('#updateDelegation').click(function() {
			    	_DELEGATION.rational = $('#_rational').val().trim();
			    	_DELEGATION.delegateName = $('#_selectDelegate').val()
			    	_DELEGATION.delegateBrid = 'G12345';
			    	_DELEGATION.startTs = $('#_start_date').val()
			    	_DELEGATION.endTs = $('#_end_date').val()
			    	_DELEGATION.delegationType = $('#_selectTaskType').val()
			    	
			    	_INDEX = 0;
			    	$.ajax({
			    		url: url,
			    		type: type,
			    		contentType: 'application/json',
			    		data: JSON.stringify(_DELEGATION),
			    		success: function(response) {
			    			$('.take-inputs').hide()
			    			$('.delegation-upd-success').html(SUCCESS_MESSAGE.replace('_DELEGATE_', _DELEGATION.delegateName));
			    			$('.show-upd-result').show()
			    			fetchDelegations()
			    		}
			    	});
			    	
			    })
			}
		},
		error: function(e) {
			
		}
	});
}

function fetchDelegations() {
	$.ajax({
		url: 'api/list/delegation',
		success: function(response) {
			var rows = ''
			for(i=0; i<response.length; i++) {
				var _ri = response[i];
				var productJourneyTasks = '';
				 var pjt = _ri.productJourneyTasks;
				 $.each(_ri.productJourneyTasks, function(k,v){
					 $.each(v, function(i, j){
						 productJourneyTasks += k + ' - ' + j + '<br>'
					 })
				 });
			    rows += ADMIN_ROW.replace('INDEX', _ri.id).replace('_DELEGATE_', _ri.delegateName + ' (' + _ri.delegateBrid +') ').replace('_D_T_T_', _ri.delegationType)
					.replace('_P_J_T_N_', productJourneyTasks).replace('_START_DATE_', _ri.startTs)
					.replace('_END_DATE_', _ri.endTs).replace('_LAST_UPDATED_', _ri.lastUpdatedTs)
					.replace('_STATUS_', 'Active');
				}
			
			$('#delegationsView').html(rows) 
			$('#components-container').show()
			
		},
		error: function(e) {
			$('#components-container').show()
		}
	});
}
