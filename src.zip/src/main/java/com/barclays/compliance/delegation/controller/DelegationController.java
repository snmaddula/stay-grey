package com.barclays.compliance.delegation.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.barclays.compliance.delegation.dto.DelegationDto;
import com.barclays.compliance.delegation.dto.DelegationPostDto;
import com.barclays.compliance.delegation.entity.DelegationEntity;
import com.barclays.compliance.delegation.service.DelegationService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping(DelegationController.API_PATH)
public class DelegationController {

	static final String API_PATH = "/api";
	private static final String SAVE_DELEGATION_API_PATH = "/saveDelegation";
	private static final String GET_DELEGATION_API_PATH = "/delegation/{id}";
	private static final String GET_ALL_DELEGATION_API_PATH = "/list/delegation";
	private static final String GET_ALL_DELEGATION_TASKS_API_PATH = "/delegation/tasks";
	private static final String UPDATE_DELEGATION_API_PATH = "/delegation/{id}";
	private static final String DELETE_DELEGATION_API_PATH = "/delegation/{id}";
	
	private final DelegationService delegationService;
	
	@GetMapping(GET_ALL_DELEGATION_API_PATH)
	public List<DelegationDto> getAllDelegations() {
		return delegationService.getAllDelegations();
	}
	
	@GetMapping(GET_DELEGATION_API_PATH)
	public DelegationDto getDelegationById(@PathVariable Long id) {
		return delegationService.getDelegationById(id);
	}
	
	@GetMapping(GET_ALL_DELEGATION_TASKS_API_PATH)
	public Map<String, Map<String, String>> productJourneyTasks() {
		return delegationService.productJourneyTasks();
	}
	
	@PostMapping(SAVE_DELEGATION_API_PATH)
	public DelegationEntity saveDelegation(@RequestBody DelegationPostDto delegation) {
		return delegationService.saveDelegation(delegation);
	}
	
	@PutMapping(UPDATE_DELEGATION_API_PATH)
	public DelegationEntity updateDelegation(@PathVariable Long id, @RequestBody DelegationPostDto delegation) {
		return delegationService.updateDelegation(id, delegation);
	}
	
	@DeleteMapping(DELETE_DELEGATION_API_PATH)
	public void deleteDelegation(@PathVariable Long id) {
		delegationService.deleteDelegation(id);
	}
	
}
