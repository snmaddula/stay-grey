package com.barclays.compliance.delegation.enums;

public enum DelegationStatus {
	Present, Past, Future
}
