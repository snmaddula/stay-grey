package com.barclays.compliance.delegation.service;

import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.barclays.compliance.delegation.entity.DelegationEntity;
import com.barclays.compliance.delegation.repo.DelegationRepo;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DelegationScheduler {

	private final DelegationRepo delegationRepo;
	
	@Scheduled(fixedDelay = 60000)
	public void updateDelegationStatus() {
		List<DelegationEntity> delegations = delegationRepo.findAll();
		for(DelegationEntity de : delegations) {
			delegationRepo.updateDelegationStatus(de.computeStatus(), de.getId());
		}
	}
}
