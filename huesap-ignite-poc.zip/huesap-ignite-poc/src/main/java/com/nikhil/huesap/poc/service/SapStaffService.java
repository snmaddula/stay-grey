package com.nikhil.huesap.poc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.nikhil.huesap.poc.entity.SapStaff;
import com.nikhil.huesap.poc.repo.SapStaffRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SapStaffService {

	private final SapStaffRepo sapStaffRepo;

	public List<SapStaff> fetchAll() {
		return sapStaffRepo.findAll();
	}

	public Optional<SapStaff> fetchById(Long id) {
		return sapStaffRepo.findById(id);
	}

	public void create(SapStaff sapStaff) {
		sapStaffRepo.save(sapStaff);
	}

	public void remove(Long id) {
		sapStaffRepo.deleteById(id);
	}

}
