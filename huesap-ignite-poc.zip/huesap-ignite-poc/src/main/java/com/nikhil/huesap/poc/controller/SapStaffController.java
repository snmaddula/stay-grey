package com.nikhil.huesap.poc.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.nikhil.huesap.poc.entity.SapStaff;
import com.nikhil.huesap.poc.service.SapStaffService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/sapstaff")
@RequiredArgsConstructor
public class SapStaffController {

	private final SapStaffService sapStaffService;

	@GetMapping
	public List<SapStaff> getAll() {
		return sapStaffService.fetchAll();
	}

	@GetMapping("{id}")
	public Optional<SapStaff> getById(@PathVariable Long id) {
		return sapStaffService.fetchById(id);
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public void create(@RequestBody SapStaff sapStaff) {
		sapStaffService.create(sapStaff);
	}

	@DeleteMapping("{id}")
	public void removeById(@PathVariable Long id) {
		sapStaffService.remove(id);
	}

}
