package com.nikhil.huesap.poc.repo;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;

import com.nikhil.huesap.poc.entity.SapStaff;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
@SuppressWarnings("unchecked")
public class SapStaffRepo {

	private final EntityManager em;

	public List<SapStaff> findAll() {
		em.getTransaction().begin();
		List<SapStaff> sapStaffList = em.createQuery("SELECT s FROM SapStaff s").getResultList();
		em.getTransaction().commit();
		return sapStaffList;
	}

	public Optional<SapStaff> findById(Long id) {
		em.getTransaction().begin();
		SapStaff sapStaff = em.find(SapStaff.class, id);
		em.getTransaction().commit();
		return Optional.ofNullable(sapStaff);
	}

	public void save(SapStaff sapStaff) {
		em.getTransaction().begin();
		em.persist(sapStaff);
		em.getTransaction().commit();
	}

	public void deleteById(Long id) {
		em.getTransaction().begin();
		em.remove(em.find(SapStaff.class, id));
		em.getTransaction().commit();
	}

}
