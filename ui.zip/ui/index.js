jQuery(function ($) {

    $(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200);
    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active");
      $(this)
        .parent()
        .removeClass("active");
    } else {
      $(".sidebar-dropdown").removeClass("active");
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200);
      $(this)
        .parent()
        .addClass("active");
    }
  });

  $('#selectDelegate').editableSelect('destroy');

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      alert('Selected delegate: ' + li.text())
    }
    $('#selectDelegate').removeClass('es-input');
  });

  $('#start-delegation').on('click', function() {
    $('#new-delegation-form').show()
  })

  $('#close-form').on('click', function() {
    $('#new-delegation-form').hide()
  })

  $("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled");
  });

  $("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled");
  });

});