
Array.prototype.remove = function (v) {
  if (this.indexOf(v) != -1) {
      this.splice(this.indexOf(v), 1)
      return true
  }
  return false
}

var INDEX = 0
const ADDED_TASK_CARD = 
`
<hr>
<div class="form-row">
  <div class="col-sm-1">&nbsp;</div>
  <div class="col-sm-10">
    <p><span class="badge badge-pill badge-primary" style="font-size:14px;">_INDEX_</span><span>&nbsp;&nbsp;</span>_TASK_TYPE_ _PRODUCT_JOURNEY_</p>
    <span style="font-size:12px;">_TASK_NAMES_</span>
  </div>
</div>
`

var TASKS_ADDED = []
jQuery(function ($) {

    $(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200)
    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .parent()
        .removeClass("active")
    } else {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200)
      $(this)
        .parent()
        .addClass("active")
    }
  })


  $('#added-tasks').hide()
  
  $('#selectDelegate').editableSelect('destroy')

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })


  $('#selectTaskType').on('change', function() {
      $('#select-journey').show()
  })

  $('#select-journey').on('change', function() {
      $('.task-names').show()
  })
  

  $('#start-delegation').on('click', function() {
    $('#added-tasks').hide()
    $('.task-names').hide()
    $('#select-journey').hide()
    $('#select-task-type').hide()
    $('.select-task-journey').hide()
    $('.add-rational').hide()
    $('.email-check').hide()
    $('#selectDelegate').val('')
    $('#selectJourney').val('')
    $('#selectTaskType').val('')
    $('#rational').val('')
    $('#selectDelegate').editableSelect('destroy')

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })

    $('.nav').addClass('nav-view');
    $('#new-delegation-form').show()
  })

  $('#close-form').on('click', function() {
    $('.nav').toggleClass('nav-view');
  })

  $("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled")
  })

  $("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled")
  })

  $('#addMoreTasks').on('click', function() {
    $('.select-task-journey').show()
    $('#select-task-type').show()
    $('#selectJourney').val('')
    $('#selectTaskType').val('')
  })


  $('.checkbox').change(function() {
    var _id = $(this)[0].id
    var _tn = $('label[for="' + _id + '"').text()  
    if(this.checked) {
      TASKS_ADDED.push(_tn)
        $('.add-task').show()
        $('#addTask').show()
    }else {
      TASKS_ADDED.remove(_tn)
      if(TASKS_ADDED.length == 0) {
        $('.add-task').hide()
        $('#addTask').hide()
      }
    }
  })

  $('#addTask').on('click', function() {
    var _tt = $('#selectTaskType').val()
    var _pj = $('#selectJourney').val()
    INDEX++
    var card = ADDED_TASK_CARD.replace('_INDEX_', INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
    $('#addedTasks').html( $('#addedTasks').html() + card)
    $('#addedTasks').show()
    $('.added-tasks').show()
    $('.task-names').hide()
    $('.select-task-journey').hide()
    $('#select-task-type').hide()
    $('.add-task').hide()
    TASKS_ADDED = []
    $('.add-rational').show()
    $('.email-check').show()
    $('.submit-delegation').show()
  })

})