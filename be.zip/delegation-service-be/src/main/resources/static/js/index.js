
Array.prototype.remove = function (v) {
  if (this.indexOf(v) != -1) {
      this.splice(this.indexOf(v), 1)
      return true
  }
  return false
};

var INDEX = 0

var PRODUCT_JOURNEY_TASKS = {}
var PRODUCT_JOURNEYS = []
var TASKS_ADDED = []
var DELEGATION = {}
const ADDED_TASK_CARD = 
`
<hr>
<div class="form-row">
  <div class="col-sm-1">&nbsp;</div>
  <div class="col-sm-10">
    <p><span class="badge badge-pill badge-primary" style="font-size:14px;">_INDEX_</span><span>&nbsp;&nbsp;</span>_TASK_TYPE_ _PRODUCT_JOURNEY_</p>
    <span style="font-size:12px;">_TASK_NAMES_</span>
  </div>
</div>
`;

let ADMIN_ROW =
`
<tr>
<td>INDEX</td>
<td>_DELEGATE_</td>
<td>_D_T_T_</td>
<td>_P_J_T_N_</td>
<td>_START_DATE_</td>
<td>_END_DATE_</td>
<td>_LAST_UPDATED_</td>
<td>_STATUS_</td>
<td style="max-width:40px; align:left;">
    <div class="dropdown show">
      <img class="rounded-circle dropdown-toggle" data-toggle="dropdown" src="img/settings.png" alt="User picture" style="max-width: 50%" aria-haspopup="true" aria-expanded="false">
      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <a class="dropdown-item" href="#">Edit</a>
        <a class="dropdown-item" href="#">Duplicate</a>
        <a class="dropdown-item" href="#">Delete</a>
      </div>
    </div>
</td>
</tr>
`;

const TASK_CARD = 
`
<div class="custom-control custom-checkbox">
	<input type="checkbox" class="xcheckbox custom-control-input" id="CHECKBOX_ID"> 
	<label class="custom-control-label" for="CHECKBOX_ID">_TASK_NAME_</label>
</div>
`;

jQuery(function ($) {
	
	fetchDelegations()
    $(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200)
    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .parent()
        .removeClass("active")
    } else {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200)
      $(this)
        .parent()
        .addClass("active")
    }
  })


  $('#added-tasks').hide()
  
  $('#selectDelegate').editableSelect('destroy')

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })


  $('#selectTaskType').on('change', function() {
      $('#select-journey').show()
  })

  $('#select-journey').on('change', function() {
      $('.task-names').show()
  })
  

  $('#start-delegation').on('click', function() {
    $('#added-tasks').hide()
    $('.task-names').hide()
    $('#select-journey').hide()
    $('#select-task-type').hide()
    $('.select-task-journey').hide()
    $('.add-rational').hide()
    $('.email-check').hide()
    $('.set-dates').hide()
    $('#selectDelegate').val('')
    $('#selectJourney').val('')
    $('#selectTaskType').val('')
    $('#rational').val('')
    $('#addedTasks').html('')
    $('.added-tasks').hide()
    $('#selectDelegate').editableSelect('destroy')
    $('.submit-delegation').hide()

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })

    $('.nav').addClass('nav-view');
    $('.take-inputs').show()
	$('.show-result').hide()
    $('#new-delegation-form').show()
  })

  $('#close-form').on('click', function() {
    $('.nav').toggleClass('nav-view');
  })

  $("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled")
  })

  $("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled")
  })

  $('.settings').on('click', function() {

  })

})


$.ajax({
  url: 'delegation/tasks',
  success: function(response) {
	  $('#selectJourney').html('<option value=""></option>')
	  PRODUCT_JOURNEY_TASKS = response;
      $.each(PRODUCT_JOURNEY_TASKS, function(k,v) {
    	  PRODUCT_JOURNEYS.push(k)
    	  $('#selectJourney').html($('#selectJourney').html() + '<option value="' + k +'">' + k + '</option>');
	  });
  }
});
	  
$('#selectJourney').on('change', function() {
	  var journey = $('#selectJourney').val();
	  if(journey != '') {
		  var tasksHtml = '';
		  $.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
			  tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
		  });
	  }
	  $('#task-names-list').html(tasksHtml)
	  $('.task-names').show()
});

$(document).on("change", ".xcheckbox", function () {
    var _id = $(this)[0].id
    var _tn = $('label[for="' + _id + '"').text()  
    if(this.checked) {
      TASKS_ADDED.push(_tn)
        $('.add-task').show()
        $('#addTask').show()
    }else {
      TASKS_ADDED.remove(_tn)
      if(TASKS_ADDED.length == 0) {
        $('.add-task').hide()
        $('#addTask').hide()
      }
    }
});


$('#emailCheck').on('change', function() {
	if(this.checked) {
		DELEGATION.emailSummaryFlag = "Y"
	}else {
		DELEGATION.emailSummaryFlag = "N"
	}
});

$('#addMoreTasks').on('click', function() {
  $('.select-task-journey').show()
  $('#select-task-type').show()
  $('#selectJourney').val('')
  $('#selectTaskType').val('')
})

$('#addTask').on('click', function() {
  var _tt = $('#selectTaskType').val()
  var _pj = $('#selectJourney').val()
  INDEX++
  var card = ADDED_TASK_CARD.replace('_INDEX_', INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
  $('#addedTasks').html( $('#addedTasks').html() + card)
  $('#addedTasks').show()
  $('.added-tasks').show()
  $('.task-names').hide()
  $('.select-task-journey').hide()
  $('#select-task-type').hide()
  $('.add-task').hide()
  
  $.each(TASKS_ADDED, function(i, v) {
	  if(DELEGATION.productJourneyTasks == undefined) {
		  DELEGATION.productJourneyTasks = []
	  }
	  DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[_pj][v] });
  });
  
  TASKS_ADDED = []
  $('.add-rational').show()
  $('.email-check').show()
  $('.set-dates').show()
  $('.submit-delegation').show()
  
})


$('#submitDelegation').click(function(){
	DELEGATION.rational = $('#rational').val().trim();
	DELEGATION.delegateName = $('#selectDelegate').val()
	DELEGATION.delegateBrid = 'G12345';
	DELEGATION.startTs = $('#start_date').val()
	DELEGATION.endTs = $('#end_date').val()
	DELEGATION.delegationType = $('#selectTaskType').val()
	console.log(DELEGATION)
	
	$.ajax({
		url: 'delegation',
		type: 'POST',
		contentType: 'application/json',
		data: JSON.stringify(DELEGATION),
		success: function(response) {
//			$('#new-delegation-form').hide()
			$('.take-inputs').hide()
			$('.show-result').show()
			fetchDelegations()
		}
	});
})


$('#startDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
}).on("dp.change", function(e) {
	$('#endDate').data("DateTimePicker").minDate(e.date);
});

$('#endDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
});


function fetchDelegations() {
	$.ajax({
		url: 'delegation',
		success: function(response) {
			var rows = ''
			for(i=0; i<response.length; i++) {
				var _ri = response[i];
				var productJourneyTasks = '';
				// var pjt = _ri.productJourneyTasks;
				// for(j=0; j<pjt.length; j++) {
				// productJourneyTasks += (j + 1) + '. ' +
				// pjt[j].productJourneyName + ' - ' + pjt[j].taskName + '<br>'
				// }
			    rows += ADMIN_ROW.replace('INDEX', _ri.id).replace('_DELEGATE_', _ri.delegateName + ' (' + _ri.delegateBrid +') ').replace('_D_T_T_', _ri.delegationType)
					.replace('_P_J_T_N_', 'productJourneyTasks').replace('_START_DATE_', _ri.startTs)
					.replace('_END_DATE_', _ri.endTs).replace('_LAST_UPDATED_', _ri.lastUpdatedTs)
					.replace('_STATUS_', 'Active');
				}
			
			$('#delegationsView').html(rows) 
			$('#components-container').show()
			
		},
		error: function(e) {
			$('#components-container').show()
		}
	});
}

