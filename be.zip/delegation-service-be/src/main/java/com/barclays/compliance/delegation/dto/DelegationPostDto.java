package com.barclays.compliance.delegation.dto;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class DelegationPostDto {

	private String delegaterBrid;
	private String delegateBrid;
	private String delegateName;
	private String delegationType;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd MMM yyyy HH:mm")
	private Timestamp startTs;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd MMM yyyy HH:mm")
	private Timestamp endTs;
	private String rational;
	private String emailSummaryFlag;
	private String lastUpdatedBy;
	private List<ProductJourneyTaskDto> productJourneyTasks;
}
