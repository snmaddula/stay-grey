package com.barclays.compliance.delegation.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.barclays.compliance.delegation.entity.DelegationEntity;
import com.barclays.compliance.delegation.enums.DelegationStatus;

@Repository
public interface DelegationRepo extends JpaRepository<DelegationEntity, Long> {

//	@Query("select de from DelegationEntity de join fetch de.productJourneyTasks pjt join fetch pjt.productJourneyId where de.deleteFlag <> 'Y'")
//	List<DelegationEntity> findNative();
	
	
	@Modifying
	@Query("update DelegationEntity e set e.deleteFlag = 'Y' where id = ?1")
	void deleteDelegation(String id);
	
	@Modifying
	@Query("update DelegationEntity e set e.status = ?1 where id = ?2")
	void updateDelegationStatus(DelegationStatus status, Long id);
	
}
