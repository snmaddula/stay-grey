var XHRS = [];
let ADMIN_ROW = '<tr><td>INDEX</td><td>_DELEGATE_</td><td>_D_T_T_</td><td>_P_J_T_N_</td><td>_START_DATE_</td><td>_END_DATE_</td><td>_LAST_UPDATED_</td><td>_STATUS_</td></tr>';

$(function() {
	
	$.ajax({
		url: 'delegation',
		success: function(response) {
			console.log(response)
			var rows = ''
			for(i=0; i<response.length; i++) {
				var _ri = response[i];
				var productJourneyTasks = '';
				var pjt = _ri.productJourneyTasks;
				for(j=0; j<pjt.length; j++) {
					productJourneyTasks += (j + 1) + '. ' + pjt[j].productJourneyId + ' - ' + pjt[j].taskName + '<br>'
				}
			    rows += ADMIN_ROW.replace('INDEX', i + 1).replace('_DELEGATE_', _ri.delegateName + ' (' + _ri.delegateBrid +') ').replace('_D_T_T_', _ri.delegationType)
					.replace('_P_J_T_N_', productJourneyTasks).replace('_START_DATE_', _ri.startTs)
					.replace('_END_DATE_', _ri.endTs).replace('_LAST_UPDATED_', _ri.lastUpdatedTs)
					.replace('_STATUS_', 'Active');
				}
			
			$('#delegationsView').html(rows) 
			$('#components-container').show()
			
		},
		error: function(e) {
			$('#components-container').show()
		}
	});
})
