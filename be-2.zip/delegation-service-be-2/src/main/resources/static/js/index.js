
Array.prototype.remove = function (v) {
  if (this.indexOf(v) != -1) {
      this.splice(this.indexOf(v), 1)
      return true
  }
  return false
};

var INDEX = 0
var _INDEX = 0

var PRODUCT_JOURNEY_TASKS = {}
var PRODUCT_JOURNEYS = []
var TASKS_ADDED = []
var DELEGATION = {}
const ADDED_TASK_CARD = 
`
<hr>
<div class="form-row">
  <div class="col-sm-1">&nbsp;</div>
  <div class="col-sm-10">
    <p><span class="badge badge-pill badge-primary" style="font-size:14px;">_INDEX_</span><span>&nbsp;&nbsp;</span>_TASK_TYPE_ _PRODUCT_JOURNEY_</p>
    <span style="font-size:12px;">_TASK_NAMES_</span>
  </div>
</div>
`;

let ADMIN_ROW =
`
<tr>
<td style="display:none">INDEX</td>
<td>_DELEGATE_</td>
<td>_D_T_T_</td>
<td>_P_J_T_N_</td>
<td>_START_DATE_</td>
<td>_END_DATE_</td>
<td>_LAST_UPDATED_</td>
<td>_STATUS_</td>
<td style="max-width:40px; align:left;">
    <div class="dropdown show">
      <img class="rounded-circle dropdown-toggle" data-toggle="dropdown" src="img/settings.png" alt="User picture" style="max-width: 40%" aria-haspopup="true" aria-expanded="false">
      <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
        <a class="dropdown-item edit-delegation" href="#">Edit</a>
        <a class="dropdown-item duplicate-delegation" href="#">Duplicate</a>
        <a class="dropdown-item delete-delegation" href="#">Delete</a>
      </div>
    </div>
</td>
</tr>
`;

const TASK_CARD = 
`
<div class="custom-control custom-checkbox">
	<input type="checkbox" class="xcheckbox custom-control-input" id="CHECKBOX_ID"> 
	<label class="custom-control-label" for="CHECKBOX_ID">_TASK_NAME_</label>
</div>
`;

jQuery(function ($) {
	
	fetchDelegations()
    $(".sidebar-dropdown > a").click(function() {
    $(".sidebar-submenu").slideUp(200)
    if (
      $(this)
        .parent()
        .hasClass("active")
    ) {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .parent()
        .removeClass("active")
    } else {
      $(".sidebar-dropdown").removeClass("active")
      $(this)
        .next(".sidebar-submenu")
        .slideDown(200)
      $(this)
        .parent()
        .addClass("active")
    }
  })


  $('#added-tasks').hide()
  
  $('#selectDelegate').editableSelect('destroy')

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })


  $('#selectTaskType').on('change', function() {
      $('#select-journey').show()
  })
  
  $('#_selectTaskType').on('change', function() {
      $('#_select-journey').show()
  })

  $('#select-journey').on('change', function() {
      $('.task-names').show()
  })

  $('#start-delegation').on('click', function() {
    $('#added-tasks').hide()
    $('.task-names').hide()
    $('#select-journey').hide()
    $('#select-task-type').hide()
    $('.select-task-journey').hide()
    $('.add-rational').hide()
    $('.email-check').hide()
    $('.set-dates').hide()
    $('#selectDelegate').val('')
    $('#selectJourney').val('')
    $('#selectTaskType').val('')
    $('#rational').val('')
    $('#addedTasks').html('')
    $('.added-tasks').hide()
    $('#selectDelegate').editableSelect('destroy')
    $('.submit-delegation').hide()

  $('#selectDelegate').editableSelect().on('select.editable-select', function (e, li) {
    if(li.text().length > 0) {
      $('.select-task-journey').show()
      $('#select-task-type').show()
    }
    $('#selectDelegate').removeClass('es-input')
  })

    $('.nav').addClass('nav-view');
    $('.take-inputs').show()
	$('.show-result').hide()
    $('#new-delegation-form').show()
    $('form[name="new"]').show();
    $('form[name="update"]').hide();
  })

  $('.close-form').on('click', function() {
    $('.nav').toggleClass('nav-view');
  })

  $("#close-sidebar").click(function() {
    $(".page-wrapper").removeClass("toggled")
  })

  $("#show-sidebar").click(function() {
    $(".page-wrapper").addClass("toggled")
  })

  $('.settings').on('click', function() {

  })

})


$.ajax({
  url: 'delegation/tasks',
  success: function(response) {
	  $('#selectJourney').html('<option value=""></option>')
	  PRODUCT_JOURNEY_TASKS = response;
      $.each(PRODUCT_JOURNEY_TASKS, function(k,v) {
    	  PRODUCT_JOURNEYS.push(k)
    	  $('#selectJourney').html($('#selectJourney').html() + '<option value="' + k +'">' + k + '</option>');
    	  $('#_selectJourney').html($('#_selectJourney').html() + '<option value="' + k +'">' + k + '</option>');
	  });
  }
});
	  
$('#selectJourney').on('change', function() {
	  var journey = $('#selectJourney').val();
	  if(journey != '') {
		  var tasksHtml = '';
		  $.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
			  tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
		  });
	  }
	  $('#task-names-list').html(tasksHtml)
	  $('.task-names').show()
});

$('#_selectJourney').on('change', function() {
	  var journey = $('#_selectJourney').val();
	  if(journey != '') {
		  var tasksHtml = '';
		  $.each(PRODUCT_JOURNEY_TASKS[journey], function(k,v){
			  tasksHtml += TASK_CARD.replace(/CHECKBOX_ID/g, 'checkbox_' + v).replace('_TASK_NAME_', k);
		  });
	  }
	  $('#_task-names-list').html(tasksHtml)
	  $('.task-names').show()
});

$(document).on('click', '.edit-delegation', function() {
	var _id = $(this).closest('tr').find("td:first").html().trim();
	editDelegation(_id)
})

$(document).on('click', '.delete-delegation', function() {
	var _id = $(this).closest('tr').find("td:first").html().trim();
	deleteDelegation(_id)
})

$(document).on("change", ".xcheckbox", function () {
    var _id = $(this)[0].id
    var _tn = $('label[for="' + _id + '"').text()  
    if(this.checked) {
      TASKS_ADDED.push(_tn)
        $('.add-task').show()
        $('#addTask').show()
        $('#_addTask').show()
    }else {
      TASKS_ADDED.remove(_tn)
      if(TASKS_ADDED.length == 0) {
        $('.add-task').hide()
        $('#addTask').hide()
        $('#_addTask').hide()
      }
    }
});


$('#emailCheck').on('change', function() {
	if(this.checked) {
		DELEGATION.emailSummaryFlag = "Y"
	}else {
		DELEGATION.emailSummaryFlag = "N"
	}
});

$('#addMoreTasks').on('click', function() {
  $('.select-task-journey').show()
  $('#select-task-type').show()
  $('#selectJourney').val('')
  $('#selectTaskType').val('')
})

$('#_addMoreTasks').on('click', function() {
  $('.select-task-journey').show()
  $('#_select-task-type').show()
  $('#_selectJourney').val('')
  $('#_selectTaskType').val('')
})

$('#addTask').on('click', function() {
  var _tt = $('#selectTaskType').val()
  var _pj = $('#selectJourney').val()
  INDEX++
  var card = ADDED_TASK_CARD.replace('_INDEX_', INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
  $('#addedTasks').html( $('#addedTasks').html() + card)
  $('#addedTasks').show()
  $('.added-tasks').show()
  $('.task-names').hide()
  $('.select-task-journey').hide()
  $('#select-task-type').hide()
  $('.add-task').hide()
  
  $.each(TASKS_ADDED, function(i, v) {
	  if(DELEGATION.productJourneyTasks == undefined) {
		  DELEGATION.productJourneyTasks = []
	  }
	  DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[_pj][v] });
  });
  
  TASKS_ADDED = []
  $('.add-rational').show()
  $('.email-check').show()
  $('.set-dates').show()
  $('.submit-delegation').show()
  
})

$('#_addTask').on('click', function() {
  var _tt = $('#_selectTaskType').val()
  var _pj = $('#_selectJourney').val()
  _INDEX++
  var card = ADDED_TASK_CARD.replace('_INDEX_', _INDEX).replace('_TASK_TYPE_', _tt).replace('_PRODUCT_JOURNEY_', _pj).replace('_TASK_NAMES_', TASKS_ADDED.join())
  $('#_addedTasks').html( $('#_addedTasks').html() + card)
  $('#_addedTasks').show()
  $('.added-tasks').show()
  $('.task-names').hide()
  $('.select-task-journey').hide()
  $('#_select-task-type').hide()
  $('.add-task').hide()
  
  $.each(TASKS_ADDED, function(i, v) {
	  if(DELEGATION.productJourneyTasks == undefined) {
		  DELEGATION.productJourneyTasks = []
	  }
	  DELEGATION.productJourneyTasks.push({'productJourneyTaskId' : PRODUCT_JOURNEY_TASKS[_pj][v] });
  });
  
  TASKS_ADDED = []
  $('.add-rational').show()
  $('.email-check').show()
  $('.set-dates').show()
  $('.submit-delegation').show()
  
})


$('#submitDelegation').click(function() {
	DELEGATION.rational = $('#rational').val().trim();
	DELEGATION.delegateName = $('#selectDelegate').val()
	DELEGATION.delegateBrid = 'G12345';
	DELEGATION.startTs = $('#start_date').val()
	DELEGATION.endTs = $('#end_date').val()
	DELEGATION.delegationType = $('#selectTaskType').val()
	console.log(DELEGATION)
	INDEX = 0;
	$.ajax({
		url: 'delegation',
		type: 'POST',
		contentType: 'application/json',
		data: JSON.stringify(DELEGATION),
		success: function(response) {
//			$('#new-delegation-form').hide()
			$('.take-inputs').hide()
			$('.delegation-success').html($('.delegation-success').html().replace('_DELEGATE_', DELEGATION.delegateName));
			$('.show-result').show()
			fetchDelegations()
		}
	});
})


$('#startDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
}).on("dp.change", function(e) {
	$('#endDate').data("DateTimePicker").minDate(e.date);
});

$('#endDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
});


function deleteDelegation(id) {
	$.ajax({
		url: 'delegation/' + id,
		type: 'DELETE',
		success: function(response) {
			alert('Deleted delegation : ' + id)
			fetchDelegations()
		},
		error: function(e) {
			
		}
	});
}

$('#_startDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
}).on("dp.change", function(e) {
	$('#_endDate').data("DateTimePicker").minDate(e.date);
});

$('#_endDate').datetimepicker({
	format : 'DD MMM YYYY HH:mm',
	defaultDate : moment()
});

function editDelegation(id) {
	DELEGATION = {}
	$.ajax({
		url: 'delegation/' + id,
		success: function(response) {
			console.log('DELEGATION :: ' + response)
			if(response) {
				DELEGATION = {}
				_INDEX = 0
				$('#_rational').val(response.rational);
				$('#_selectDelegate').val(response.delegateName);
				$('#_startDate').data("DateTimePicker").date(null)
				$('#_endDate').data("DateTimePicker").date(null)
				$('#_startDate').data("DateTimePicker").date(moment(response.startTs, 'DD MMM YYYY HH:mm'))
				$('#_endDate').data("DateTimePicker").date(moment(response.endTs, 'DD MMM YYYY HH:mm'))
				$('#_selectTaskType').val(response.delegationType)
				console.log(JSON.stringify(response))	
				$('#_addedTasks').html('')
				
				var tasksHtml = '';
				$.each(response.productJourneyTasks, function(k,v) {
					_INDEX++;
					var card = ADDED_TASK_CARD.replace('_INDEX_', _INDEX).replace('_TASK_TYPE_', response.delegationType).replace('_PRODUCT_JOURNEY_', k).replace('_TASK_NAMES_', v.join())
					  $('#_addedTasks').html( $('#_addedTasks').html() + card)
					  $('#_addedTasks').show()
					  $('.added-tasks').show()
					  $('.task-names').hide()
					  $('.select-task-journey').hide()
					  $('#select-task-type').hide()
					  $('.add-task').hide()
				})
				
				$('#added-tasks').show()
			    $('.task-names').show()
			    $('#select-journey').show()
			    $('#select-task-type').hide()
			    $('.select-task-journey').hide()
			    $('.add-rational').show()
			    $('.email-check').show()
			    $('.set-dates').show()
			    $('.added-tasks').show()
			    $('.submit-delegation').hide()

			    $('.nav').addClass('nav-view');
			    $('.take-inputs').show()
				$('.show-result').hide()
			    $('#new-delegation-form').show()
			    $('form[name="new"]').hide();
			    $('form[name="update"]').show();
			}
		},
		error: function(e) {
			
		}
	});
}

function fetchDelegations() {
	$.ajax({
		url: 'delegation',
		success: function(response) {
			var rows = ''
			for(i=0; i<response.length; i++) {
				var _ri = response[i];
				var productJourneyTasks = '';
				 var pjt = _ri.productJourneyTasks;
				 $.each(_ri.productJourneyTasks, function(k,v){
					 $.each(v, function(i, j){
						 productJourneyTasks += k + ' - ' + j + '<br>'
					 })
				 });
			    rows += ADMIN_ROW.replace('INDEX', _ri.id).replace('_DELEGATE_', _ri.delegateName + ' (' + _ri.delegateBrid +') ').replace('_D_T_T_', _ri.delegationType)
					.replace('_P_J_T_N_', productJourneyTasks).replace('_START_DATE_', _ri.startTs)
					.replace('_END_DATE_', _ri.endTs).replace('_LAST_UPDATED_', _ri.lastUpdatedTs)
					.replace('_STATUS_', 'Active');
				}
			
			$('#delegationsView').html(rows) 
			$('#components-container').show()
			
		},
		error: function(e) {
			$('#components-container').show()
		}
	});
}

