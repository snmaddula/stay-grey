package com.barclays.compliance.delegation.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.barclays.compliance.delegation.dto.DelegationDto;
import com.barclays.compliance.delegation.dto.DelegationPostDto;
import com.barclays.compliance.delegation.dto.ProductJourneyTaskDto;
import com.barclays.compliance.delegation.entity.DelegationEntity;
import com.barclays.compliance.delegation.entity.ProductJourneyTaskEntity;
import com.barclays.compliance.delegation.repo.DelegationRepo;
import com.barclays.compliance.delegation.repo.ProductJourneyTaskRepo;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DelegationService {

	private final DelegationRepo delegationRepo;
	private final ProductJourneyTaskRepo productJourneyTaskRepo;
	
	private Set<ProductJourneyTaskEntity> prepareTaskEntityList(List<ProductJourneyTaskDto> productJourneyTaskDtos) {
		return productJourneyTaskDtos.stream().map(pjt -> productJourneyTaskRepo.findById(pjt.getProductJourneyTaskId()).get()).collect(Collectors.toSet());
	}
	
	public DelegationEntity saveDelegation(DelegationPostDto dto) {
		return delegationRepo.save(toEntity(dto));
	}

	public List<DelegationDto> getAllDelegations() {
		return delegationRepo.findAll().stream().map(this::toDto).collect(Collectors.toList());
	}
	
	@Transactional
	public void deleteDelegation(Long id) {
		delegationRepo.deleteDelegationTasks(id);
		delegationRepo.deleteDelegation(id);
	}
	
	public Map<String, Map<String, String>> productJourneyTasks() {
		Map<String, Map<String, String>> productJourneyTasks = new HashMap<>();
		
		List<ProductJourneyTaskEntity> entities = productJourneyTaskRepo.findAll();
		
		for(ProductJourneyTaskEntity pjte : entities) {
			String journey = pjte.getProductJourney().getProductJourneyName();
			if(!productJourneyTasks.containsKey(journey)) {
				productJourneyTasks.put(journey, new HashMap<>());
			}
			productJourneyTasks.get(journey).put(pjte.getTaskName(), pjte.getId());
		}
		
		return productJourneyTasks;
//		return productJourneyTaskRepo.findAll().stream().collect(Collectors.groupingBy(pjte -> pjte.getProductJourney().getProductJourneyName())).keySet();
//		return productJourneyTaskRepo.findAll();
	}
	
	public DelegationEntity toEntity(DelegationPostDto dto) {
		DelegationEntity entity = new DelegationEntity();
		entity.setDelegateBrid(dto.getDelegateBrid());
		entity.setDelegateName(dto.getDelegateName());
		entity.setDelegaterBrid(dto.getDelegaterBrid());
		entity.setDelegationType(dto.getDelegationType());
		entity.setEmailSummaryFlag(dto.getEmailSummaryFlag());
		entity.setRational(dto.getRational());
		entity.setStartTs(dto.getStartTs());
		entity.setEndTs(dto.getEndTs());
		entity.setProductJourneyTasks(prepareTaskEntityList(dto.getProductJourneyTasks()));
		return entity;
	}
	
	
	public DelegationDto toDto(DelegationEntity entity) {
		if(entity == null) return null;
		DelegationDto dto = new DelegationDto();
		dto.setId(entity.getId());
		dto.setDelegateBrid(entity.getDelegateBrid());
		dto.setDelegateName(entity.getDelegateName());
		dto.setDelegaterBrid(entity.getDelegaterBrid());
		dto.setDelegationType(entity.getDelegationType());
		dto.setEndTs(entity.getEndTs());
		dto.setStartTs(entity.getStartTs());
		dto.setStatus(entity.getStatus());
		dto.setLastUpdatedTs(entity.getLastUpdatedTs());
		dto.setRational(entity.getRational());
		Set<ProductJourneyTaskEntity> tasks = entity.getProductJourneyTasks();
		Map<String, List<String>> _tasks = new HashMap<>();
		for(ProductJourneyTaskEntity pjte : tasks) {
			String journey = pjte.getProductJourney().getProductJourneyName();
			if(!_tasks.containsKey(journey)) {
				_tasks.put(journey, new ArrayList<>());
			}
			_tasks.get(journey).add(pjte.getTaskName());
		}
		dto.setProductJourneyTasks(_tasks);
		
		return dto;
	}

	public DelegationDto getDelegationById(Long id) {
		return toDto(delegationRepo.findById(id).orElse(null));
	}
	
}
