package com.barclays.compliance.delegation.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "PRODUCT_JOURNEY_TASK")
public class ProductJourneyTaskEntity {

	@Id
	private String id;

	@ManyToOne
	private ProductJourneyEntity productJourney;
	
	private String taskName;

}
