package com.nikhil.huesap.demo;

import java.util.Arrays;

import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;
import org.hibernate.ogm.datastore.ignite.IgniteConfigurationBuilder;

import com.nikhil.huesap.demo.entity.SapEmployeeGroup;
import com.nikhil.huesap.demo.entity.SapEmployeeSubGroup;
import com.nikhil.huesap.demo.entity.SapEntity;
import com.nikhil.huesap.demo.entity.SapLocation;
import com.nikhil.huesap.demo.entity.SapOrgDepartment;
import com.nikhil.huesap.demo.entity.SapOrgUnit;
import com.nikhil.huesap.demo.entity.SapStaff;


public class IgniteConfig implements IgniteConfigurationBuilder {

	public IgniteConfiguration build() {
		return new IgniteConfiguration() {
			{
				setPeerClassLoadingEnabled(true);
				setClientMode(true);
				new TcpDiscoverySpi() {
					{
						setIpFinder(new TcpDiscoveryMulticastIpFinder() {
							{
								setAddresses(Arrays.asList("127.0.0.1:47500..47509"));
							}
						});
					}
				};
				setCacheConfiguration(new CacheConfiguration<Long, SapStaff>("SapStaff"));
				setCacheConfiguration(new CacheConfiguration<String, SapEntity>("SapEntity"));
				setCacheConfiguration(new CacheConfiguration<String, SapOrgUnit>("SapOrgUnit"));
				setCacheConfiguration(new CacheConfiguration<Long, SapLocation>("SapLocation"));
				setCacheConfiguration(new CacheConfiguration<String, SapOrgDepartment>("SapOrgDepartment"));
				setCacheConfiguration(new CacheConfiguration<String, SapEmployeeGroup>("SapEmployeeGroup"));
				setCacheConfiguration(new CacheConfiguration<String, SapEmployeeSubGroup>("SapEmployeeSubGroup"));
			}
		};
	}

}
